package Lab;
/**
 * Name: Ngoc Duy Nguyen
 * Date: January 18th, 2022
 * Description: Hello World program
 */
public class Hello {
    /**
     * Main function
     * @param args This code will print out "Hello World"
     */

    public static void main(String[] args){
        System.out.print("Hello World");
    }

}
